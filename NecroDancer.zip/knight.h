#pragma once
#include "enemy.h"
class knight :
	public enemy
{
private:
	const int ANIMATION_FPS = 8;
public:
	knight();
	~knight();
};

