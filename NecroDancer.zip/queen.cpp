#include "stdafx.h"
#include "queen.h"


queen::queen()
{
}


queen::~queen()
{
}

HRESULT queen::init()
{
	imageInit();

	_maxHp = 1;
	_curHp = _maxHp;
	_speed = SPEED * 2;
	_dmg = 3;
	_posZ = 0;
	_enemyType = QUEEN;
	_isNeedAstar = true;
	_savePos = _posLT;
	_gold = 0;
	_isFind = true;

	return S_OK;
}

void queen::release()
{
}

void queen::update()
{
	if (_isFind && _isBeat)
	{
		_isBeat = false;
	}
}

void queen::render()
{
}

void queen::imageInit()
{
	IMAGEMANAGER->addFrameImage("queen", L"images/monster/boss/queen.png", 66, 156, 1, 2);
	_img = IMAGEMANAGER->findImage("bishop");

	IMAGEMANAGER->addImage("shadow_Standard", L"images/monster/normal/shadow_Standard.png", 48, 54);
	_shadowImg = IMAGEMANAGER->findImage("shadow_Standard");

	IMAGEMANAGER->addFrameImage("dust", L"images/monster/normal/dust.png", 240, 48, 5, 1);
	_dustImg = IMAGEMANAGER->findImage("dust");

	KEYANIMANAGER->addAnimationType("dust");

	int dust[] = { 0,1,2,3,4 };
	KEYANIMANAGER->addArrayFrameAnimation("dust", "dust_Ani", "dust", dust, 5, 10, false);

	_dustAni = KEYANIMANAGER->findAnimation("dust", "dust_Ani");
}

void queen::moveCal()
{
}
