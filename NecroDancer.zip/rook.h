#pragma once
#include "enemy.h"

class rook : public enemy
{
private:
	const int ANIMATION_FPS = 5;
public:
	rook();
	~rook();

	HRESULT init();
	void release();
	void update();
	void render();
	
	//=========================================================
	//						init
	//=========================================================
	void imageInit();


	void moveCal();
	void firstMoveCal();
};

