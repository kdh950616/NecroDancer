#include "stdafx.h"
#include "knight.h"


knight::knight()
{
}


knight::~knight()
{
}
