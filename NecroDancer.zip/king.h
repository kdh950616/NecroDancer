#pragma once
#include "enemy.h"
class king :
	public enemy
{
private:
	const int ANIMATION_FPS = 8;
public:
	king();
	~king();
};

