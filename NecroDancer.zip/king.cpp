#include "stdafx.h"
#include "king.h"


king::king()
{
}


king::~king()
{
}
